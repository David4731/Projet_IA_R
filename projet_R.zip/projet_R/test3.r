library(imager)
library(caTools)

# Chemins des images
image_dirs <- c("dataset/banane", "dataset/pomme")
print(image_dirs)
image_paths <- unlist(lapply(image_dirs, function(dir) list.files(dir, full.names = TRUE)))

print(image_paths)  # Vérifie les chemins des images

# Fonction pour charger et prétraiter les images
load_and_preprocess_image <- function(file_path) {
  img <- load.image(file_path)
  img <- resize(img, size_x = 64, size_y = 64)
  img_vector <- as.numeric(img)
  return(img_vector)
}

# Charger et prétraiter les données d'images
image_data <- lapply(image_paths, load_and_preprocess_image)

# Extraire les étiquettes des noms de fichiers
labels <- factor(sapply(strsplit(basename(dirname(image_paths)), "/"), `[`, 1))
print(table(labels))  # Vérifie les étiquettes extraites

# Vérifie que les données d'image sont correctement chargées
if (length(image_data) == 0 || any(sapply(image_data, length) == 0)) {
  stop("Erreur : Les données d'images sont vides ou non correctement chargées.")
}

# Créer une matrice des données d'image
image_matrix <- do.call(rbind, image_data)
data <- data.frame(image_matrix)
data$label <- labels

# Vérifier les types des données avant la division
str(data)
print(head(data))

# S'assurer que les étiquettes sont correctement ajoutées
if (nrow(data) == 0) {
  stop("Le data frame est vide.")
}

if (length(levels(data$label)) == 0) {
  stop("La colonne 'label' est vide.")
}

# Diviser les données en ensembles d'entraînement et de test
set.seed(123)
split <- sample.split(data$label, SplitRatio = 0.7)

# Vérifier la structure de `split`
print(table(split))

# Diviser les données en ensembles d'entraînement et de test
train_data <- subset(data, split == TRUE)
test_data <- subset(data, split == FALSE)

# Construire le modèle
model <- glm(label ~ ., data = train_data, family = binomial())

# Fonction pour charger et prétraiter une nouvelle image
load_and_preprocess_new_image <- function(file_path) {
  img <- load.image(file_path)
  img <- resize(img, size_x = 64, size_y = 64)
  img_vector <- as.numeric(img)
  return(img_vector)
}

# Chemin de la nouvelle image pour la prédiction
new_image_path <- "pomme_test.jpeg"

# Charger et prétraiter la nouvelle image
new_image_data <- load_and_preprocess_new_image(new_image_path)

# Préparer les données de la nouvelle image pour la prédiction
new_image_df <- as.data.frame(t(new_image_data))
names(new_image_df) <- names(data)[-ncol(data)]  # Assurez-vous que les noms de colonnes correspondent à ceux du modèle

print("Données de la nouvelle image pour la prédiction :")
print(dim(new_image_df))
print(head(new_image_df))

# Prédire la classe de la nouvelle image
prediction <- predict(model, new_image_df, type = "response")
print(prediction)
